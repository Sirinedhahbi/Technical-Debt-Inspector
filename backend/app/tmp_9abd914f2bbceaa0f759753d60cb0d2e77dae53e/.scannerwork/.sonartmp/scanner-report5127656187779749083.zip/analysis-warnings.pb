�
�SCM provider autodetection failed. Please use "sonar.scm.provider" to define SCM of your project, or disable the SCM Sensor in the project settings.Ⱘ��3�
wJavaScript/TypeScript/CSS rules were not executed. Error when running: 'node -v'. Is Node.js available during analysis?�����3